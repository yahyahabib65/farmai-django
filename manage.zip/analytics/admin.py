from django.contrib import admin 
from .models import AnalyticsResult
from import_export.admin import ImportExportModelAdmin


@admin.register(AnalyticsResult)
class AnalyticsResultAdmin(admin.ModelAdmin):
    list_display = ('field', 'date', 'avg_ndvi', 'irrigation_alert')
    list_filter = ('irrigation_alert', 'date')