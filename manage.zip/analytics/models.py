from django.db import models

class AnalyticsResult(models.Model):
    # Link to a specific field using lazy reference
    field = models.ForeignKey('core.FieldBoundary', on_delete=models.CASCADE)
    
    # When did we run this check?
    date = models.DateField(auto_now_add=True)
    
    # The calculated health score (NDVI)
    avg_ndvi = models.FloatField(help_text="Average NDVI value (0-1)")
    
    # Did the system flag this field?
    irrigation_alert = models.BooleanField(default=False)
    
    # Extra notes (e.g., "Low moisture detected")
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.field.name} - {self.date}"