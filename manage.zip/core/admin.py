from django.contrib import admin
from django.contrib.gis import admin as gis_admin
from import_export.admin import ImportExportModelAdmin
from .models import Farm, FieldBoundary, Device, Asset


@admin.register(Farm)
class FarmAdmin(ImportExportModelAdmin):
    list_display = ('name', 'owner', 'location', 'created_at')
    search_fields = ('name', 'owner__username')


@admin.register(FieldBoundary)
class FieldBoundaryAdmin(gis_admin.GISModelAdmin):
    list_display = ('name', 'farm', 'crop_type', 'area_hectares', 'created_at')
    search_fields = ('name', 'farm__name')


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ('name', 'farm', 'field', 'device_type', 'status', 'last_seen')
    search_fields = ('name', 'thingsboard_id')
    list_filter = ('device_type', 'status')


@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = ('name', 'asset_type', 'farm', 'field', 'device', 'serial_number')
    search_fields = ('name', 'serial_number')
    list_filter = ('asset_type',)