"""
URL configuration for farm_system project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from imagery.views import DroneImageViewSet, DroneImageUploadView, AnalyticsView, SentinelImageUploadView
from core.views import FarmViewSet, FieldBoundaryViewSet, DeviceViewSet, AssetViewSet, ManualImportView, farm_data_view, farm_filter_view
from iot.views import SensorReadingViewSet
from django.http import HttpResponse

router = DefaultRouter()
router.register(r'imagery', DroneImageViewSet, basename='droneimage')
router.register(r'farms', FarmViewSet, basename='farm')
router.register(r'fields', FieldBoundaryViewSet, basename='field')
router.register(r'devices', DeviceViewSet, basename='device')
router.register(r'assets', AssetViewSet, basename='asset')
router.register(r'readings', SensorReadingViewSet, basename='reading')

def home_view(request):
    return HttpResponse('<h1>Welcome to FarmAI</h1><p>Navigate to <a href="/analytics/dashboard/">Dashboard</a></p>')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('analytics/', include('analytics.urls')),
    path('api/', include(router.urls)),
    path('api/manual-import/', ManualImportView.as_view(), name='manual-import'),
    path('api/drone-upload/', DroneImageUploadView.as_view(), name='drone-upload'),
    path('api/analytics/run/', AnalyticsView.as_view(), name='analytics-run'),
    path('api/sentinel-upload/', SentinelImageUploadView.as_view(), name='sentinel-upload'),
    path('', home_view, name='home'),
    path('api/farms/<int:farm_id>/data/', farm_data_view, name='farm-data'),
    path('api/farms/filter/', farm_filter_view, name='farm-filter'),
]
