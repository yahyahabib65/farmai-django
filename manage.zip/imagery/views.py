from rest_framework import viewsets, status
from rest_framework.response import Response
from .models import DroneImage
from .serializers import DroneImageSerializer
from .tasks import process_ndvi
from minio import Minio
import os
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from django.shortcuts import get_object_or_404
from core.models import FieldBoundary, Farm
from django.conf import settings
from geoai import semantic_segmentation, semantic_segmentation_batch

# MinIO Client
client = Minio(
    "localhost:9000",
    access_key="minioadmin",
    secret_key="minioadmin",
    secure=False
)

class DroneImageViewSet(viewsets.ModelViewSet):
    queryset = DroneImage.objects.all()
    serializer_class = DroneImageSerializer

    def create(self, request, *args, **kwargs):
        # 1. Check if file is in request
        file_obj = request.FILES.get('image')
        if not file_obj:
            return Response({"error": "No image provided"}, status=400)

        # 2. Upload to MinIO
        bucket_name = "farm-data"
        if not client.bucket_exists(bucket_name):
            client.make_bucket(bucket_name)

        # Create unique filename: farm_id/filename
        farm_id = request.data.get('farm')
        file_path = f"raw/{farm_id}/{file_obj.name}"
        
        # Upload stream (requires known size)
        client.put_object(
            bucket_name,
            file_path,
            file_obj,
            file_obj.size
        )

        # 3. Save to DB
        drone_image = DroneImage.objects.create(
            farm_id=farm_id,
            minio_path=file_path
        )

        # 4. Trigger Analysis Task (Async)
        process_ndvi.delay(drone_image.id)

        serializer = self.get_serializer(drone_image)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class DroneImageUploadView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        field_id = request.data.get('field_id')
        field = get_object_or_404(FieldBoundary, id=field_id)

        file_obj = request.FILES.get('file')
        if not file_obj:
            return Response({'error': 'No file uploaded'}, status=status.HTTP_400_BAD_REQUEST)

        # MinIO client setup
        minio_client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=False
        )

        bucket_name = settings.MINIO_BUCKET_NAME
        if not minio_client.bucket_exists(bucket_name):
            minio_client.make_bucket(bucket_name)

        # Upload file to MinIO
        file_path = f"drone-images/{field.id}/{file_obj.name}"
        minio_client.put_object(
            bucket_name,
            file_path,
            file_obj,
            length=file_obj.size,
            content_type=file_obj.content_type
        )

        # Link image to field (optional: save metadata in DB if needed)
        return Response({
            'message': 'File uploaded successfully',
            'field_id': field.id,
            'file_path': file_path
        }, status=status.HTTP_201_CREATED)

class AnalyticsView(APIView):
    def post(self, request, *args, **kwargs):
        image_path = request.data.get('image_path')
        if not image_path:
            return Response({'error': 'Image path is required'}, status=status.HTTP_400_BAD_REQUEST)

        # MinIO client setup
        minio_client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=False
        )

        bucket_name = settings.MINIO_BUCKET_NAME
        if not minio_client.bucket_exists(bucket_name):
            return Response({'error': 'MinIO bucket does not exist'}, status=status.HTTP_400_BAD_REQUEST)

        # Download image from MinIO
        try:
            response = minio_client.get_object(bucket_name, image_path)
            with open('/tmp/temp_image.tif', 'wb') as file_data:
                for d in response.stream(32*1024):
                    file_data.write(d)
        except Exception as e:
            return Response({'error': f'Failed to download image: {e}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        # Process image using GeoAI
        try:
            ndvi_result = semantic_segmentation('/tmp/temp_image.tif')
            ndwi_result = semantic_segmentation('/tmp/temp_image.tif')
        except Exception as e:
            return Response({'error': f'GeoAI processing failed: {e}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        # Save results back to MinIO
        try:
            ndvi_path = image_path.replace('raw', 'processed/ndvi')
            ndwi_path = image_path.replace('raw', 'processed/ndwi')

            minio_client.put_object(bucket_name, ndvi_path, ndvi_result, len(ndvi_result))
            minio_client.put_object(bucket_name, ndwi_path, ndwi_result, len(ndwi_result))
        except Exception as e:
            return Response({'error': f'Failed to upload results: {e}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({
            'message': 'Analytics completed successfully',
            'ndvi_path': ndvi_path,
            'ndwi_path': ndwi_path
        }, status=status.HTTP_200_OK)

class SentinelImageUploadView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        farm_id = request.data.get('farm_id')
        farm = get_object_or_404(Farm, id=farm_id)

        file_obj = request.FILES.get('file')
        if not file_obj:
            return Response({'error': 'No file uploaded'}, status=status.HTTP_400_BAD_REQUEST)

        # MinIO client setup
        minio_client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=False
        )

        bucket_name = settings.MINIO_BUCKET_NAME
        if not minio_client.bucket_exists(bucket_name):
            minio_client.make_bucket(bucket_name)

        # Upload file to MinIO
        file_path = f"sentinel-images/{farm.id}/{file_obj.name}"
        minio_client.put_object(
            bucket_name,
            file_path,
            file_obj,
            length=file_obj.size,
            content_type=file_obj.content_type
        )

        # Store metadata (optional: extend Farm or create a new model for Sentinel metadata)
        return Response({
            'message': 'Sentinel image uploaded successfully',
            'farm_id': farm.id,
            'file_path': file_path
        }, status=status.HTTP_201_CREATED)