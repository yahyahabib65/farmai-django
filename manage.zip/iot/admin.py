from django.contrib import admin
from .models import SensorReading
from import_export.admin import ImportExportModelAdmin

@admin.register(SensorReading)
class SensorReadingAdmin(ImportExportModelAdmin):
    list_display = ('device', 'timestamp', 'temperature', 'moisture')
    list_filter = ('device', 'timestamp')