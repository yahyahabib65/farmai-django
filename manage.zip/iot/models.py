from django.db import models
# Note: We do NOT import Device here anymore to avoid the error.

class SensorReading(models.Model):
    # We use quotes 'core.Device' to tell Django: 
    # "Look for a model named Device in the core app later."
    device = models.ForeignKey('core.Device', on_delete=models.CASCADE, related_name='readings')
    
    timestamp = models.DateTimeField()
    temperature = models.FloatField(null=True, blank=True)
    moisture = models.FloatField(null=True, blank=True)
    
    class Meta:
        get_latest_by = 'timestamp'

    def __str__(self):
        # We can still access self.device.name normally here
        return f"{self.device.name} - {self.timestamp}"