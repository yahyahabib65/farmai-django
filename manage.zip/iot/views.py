from rest_framework import viewsets
from rest_framework.permissions import AllowAny
from .models import SensorReading
from .serializers import SensorReadingSerializer


class SensorReadingViewSet(viewsets.ModelViewSet):
	queryset = SensorReading.objects.select_related('device').all()
	serializer_class = SensorReadingSerializer
	permission_classes = (AllowAny,)
